
<?php $__env->startSection("title", "帳號管理"); ?>
<?php $__env->startSection("content"); ?>
<div class="admin-card" data-crud-list>
    <div class="admin-card-header">
        <h2><i class="fa fa-user-shield"></i> 管理員列表</h2>
        <div class="admin-toolbar">
            <!-- 關鍵字即時查詢：輸入時自動篩選並標示關鍵字 -->
            <form class="search-box">
                <i class="fa fa-search"></i>
                <input type="search" name="keyword" class="form-control" placeholder="搜尋姓名 / 帳號 / Email" autocomplete="off" />
            </form>
            <button type="button" class="btn btn-light btn-sm" data-clear><i class="fa fa-times"></i> 清除</button>
            <a href="/admin/manager/create" class="btn btn-gold btn-sm"><i class="fa fa-plus"></i> 新增管理員</a>
        </div>
    </div>

    <div class="table-wrap">
        <table class="data-table admin-table">
            <thead>
                <tr>
                    <th>帳號</th>
                    <th>密碼</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-row>
                    <td data-mark><?php echo e($data->userId); ?></td>
                    <td data-mark><?php echo e($data->pwd); ?></td>
                    <td>
                        <div class="actions">
                            <a href="/admin/manager/edit/<?php echo e($data->id); ?>" class="btn btn-outline btn-xs"><i class="fa fa-edit"></i> 修改</a>
                            <button type="button" class="btn btn-danger-outline btn-xs" data-delete data-name="系統管理員" data-blocked="不能刪除目前登入中的帳號"><i class="fa fa-trash"></i> 刪除</button></div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="admin-table-info">
        <span>共 <b><?php echo e($total); ?></b> 筆</span>
        <nav class="pagination">
            <?php echo e($list->links()); ?>

        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\user\Desktop\web0921\php\project2610\resources\views/admin/manager/list.blade.php ENDPATH**/ ?>