<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class Manager extends Model
{
    // timestamps = false:表示不要用Laravel硬塞的二個時間欄位create_at及update_at
    public $timestamps = false;
    // 資料表名稱
    protected $table = "manager";
    // 主鍵名稱
    protected $primaryKey = 'id';
    // manager資料表中的欄位名稱
    protected $fillable = ["id", "userId", "pwd"];

    public function getManager(string $userId, string $pwd)
    {
        /*

            self:manager這個資料表
            first():取第一筆資料
            下列的語法= SELECT * FROM manager WHERE userId = xxx AND pwd = xxx LIMIT 1
        */
        $manager = self::where("userId", $userId)->where("pwd", $pwd)->first();
        return $manager;
    }
}
