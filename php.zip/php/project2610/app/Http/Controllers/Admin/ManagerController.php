<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Manager;
use Illuminate\Http\Request;

class ManagerController extends Controller
{
    public function list()
    {
        // get:取得全部資料, 也可以用all -> Manager::all();
        // 將取得的資料以$list變數儲存
        $list = Manager::paginate(1);
        // 計算總比數
        $total = Manager::count();
        // compact: 將資料渲染到admin.manager.list這個網頁
        // compact("list"): 這個list為上一行的$list, 二個名稱要一樣
        return view("admin.manager.list", compact("list", "total"));
    }

    public function create()
    {
        return view("admin.manager.create");
    }
}
